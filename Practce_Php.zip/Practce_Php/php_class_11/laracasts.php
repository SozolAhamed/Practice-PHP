
<?php


    $business =[
        'name' => 'WPity',
        'cost' => 15,
        'categories' => ["php", "wordpress", "javascript"]

        ];
        
       function register($user) {
        // Create the user record in the db
        // Log them in
        //Send a welcome  email
        // Redirect to their new dashboard

       }
        
require "index.view.php";